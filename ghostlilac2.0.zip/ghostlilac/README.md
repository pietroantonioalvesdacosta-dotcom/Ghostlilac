# GhostLilac 0.2.0 - Fabric 1.21.4

Efeitos: Trail, Shockwave (ao pousar), Sky lilas animado, Chroma (pack), Cyberspace (pack opcional),
Hitsplash e Afterglow (desligados por padrao).

Teclas: M trail, L shockwave, B sky, J hitsplash, K afterglow, V testar shockwave.
Packs: Opcoes > Pacotes de recursos > GhostLilac Chroma (ligado) / GhostLilac Cyberspace (opcional).
