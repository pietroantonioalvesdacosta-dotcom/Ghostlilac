package com.ghostlilac.mixin;

import com.ghostlilac.Effects;
import com.ghostlilac.GhostLilacClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public abstract class SkyColorVecMixin {
    @Inject(method = "getSkyColor(Lnet/minecraft/util/math/Vec3d;F)Lnet/minecraft/util/math/Vec3d;",
            at = @At("RETURN"), cancellable = true, require = 0)
    private void ghostlilac$sky(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Vec3d> cir) {
        if (!GhostLilacClient.sky) return;
        Vec3d o = cir.getReturnValue();
        long time = ((ClientWorld) (Object) this).getTime();
        float[] c = Effects.skyRgb((float) o.x, (float) o.y, (float) o.z, time, tickDelta);
        cir.setReturnValue(new Vec3d(c[0], c[1], c[2]));
    }
}
