package com.ghostlilac.mixin;

import com.ghostlilac.Effects;
import com.ghostlilac.GhostLilacClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public abstract class SkyColorIntMixin {
    @Inject(method = "getSkyColor(Lnet/minecraft/util/math/Vec3d;F)I",
            at = @At("RETURN"), cancellable = true, require = 0)
    private void ghostlilac$sky(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Integer> cir) {
        if (!GhostLilacClient.sky) return;
        int o = cir.getReturnValue();
        float r = ((o >> 16) & 255) / 255f;
        float g = ((o >> 8) & 255) / 255f;
        float b = (o & 255) / 255f;
        long time = ((ClientWorld) (Object) this).getTime();
        float[] c = Effects.skyRgb(r, g, b, time, tickDelta);
        int out = 0xFF000000 | ((int) (c[0] * 255) << 16) | ((int) (c[1] * 255) << 8) | (int) (c[2] * 255);
        cir.setReturnValue(out);
    }
}
