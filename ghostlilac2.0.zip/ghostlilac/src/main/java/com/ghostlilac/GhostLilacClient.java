package com.ghostlilac;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class GhostLilacClient implements ClientModInitializer {
    public static boolean hitsplash = false;
    public static boolean afterglow = false;
    public static boolean shockwave = true;
    public static boolean trail = true;
    public static boolean sky = true;

    private static final int COLOR = 0xFFC9A7FF;

    private static KeyBinding kHit, kGlow, kShock, kTrail, kSky, kTest;
    private static LivingEntity lastTarget;
    private static long lastTargetTick;
    private static boolean prevOnGround = true;
    private static double prevVy = 0;

    @Override
    public void onInitializeClient() {
        kHit   = key("key.ghostlilac.hitsplash",  GLFW.GLFW_KEY_J);
        kGlow  = key("key.ghostlilac.afterglow",  GLFW.GLFW_KEY_K);
        kShock = key("key.ghostlilac.shockwave",  GLFW.GLFW_KEY_L);
        kTrail = key("key.ghostlilac.trail",      GLFW.GLFW_KEY_M);
        kSky   = key("key.ghostlilac.sky",        GLFW.GLFW_KEY_B);
        kTest  = key("key.ghostlilac.test_shock", GLFW.GLFW_KEY_V);

        // Packs de recursos embutidos: Chroma (ligado por padrao) e Cyberspace (desligado)
        FabricLoader.getInstance().getModContainer("ghostlilac").ifPresent(c -> {
            ResourceManagerHelper.registerBuiltinResourcePack(
                    Identifier.of("ghostlilac", "chroma"), c,
                    Text.literal("GhostLilac Chroma"), ResourcePackActivationType.DEFAULT_ENABLED);
            ResourceManagerHelper.registerBuiltinResourcePack(
                    Identifier.of("ghostlilac", "cyberspace"), c,
                    Text.literal("GhostLilac Cyberspace"), ResourcePackActivationType.NORMAL);
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient && entity instanceof LivingEntity living) {
                Vec3d p = living.getPos().add(0, living.getHeight() * 0.6, 0);
                if (hitsplash) Effects.hitSplash(p);
                lastTarget = living;
                lastTargetTick = world.getTime();
            }
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (kHit.wasPressed())   hitsplash = toggle(client, "Hitsplash", hitsplash);
            while (kGlow.wasPressed())  afterglow = toggle(client, "Afterglow", afterglow);
            while (kShock.wasPressed()) shockwave = toggle(client, "Shockwave", shockwave);
            while (kTrail.wasPressed()) trail = toggle(client, "Trail", trail);
            while (kSky.wasPressed())   sky = toggle(client, "Sky", sky);
            while (kTest.wasPressed()) {
                if (client.player != null) Effects.startShockwave(client.player.getPos());
            }

            ClientPlayerEntity p = client.player;
            if (p != null) {
                boolean on = p.isOnGround();
                // pousou depois de cair: dispara a onda
                if (shockwave && !prevOnGround && on && prevVy < -0.5) {
                    Effects.startShockwave(p.getPos());
                }
                prevOnGround = on;
                prevVy = p.getVelocity().y;
                if (trail) Effects.trail(p);
            }

            Effects.tick();

            if (lastTarget != null && client.world != null) {
                if (!lastTarget.isAlive()) {
                    if (afterglow) {
                        Effects.afterglow(lastTarget.getPos(), lastTarget.getHeight(), lastTarget.getWidth());
                    }
                    lastTarget = null;
                } else if (client.world.getTime() - lastTargetTick > 100) {
                    lastTarget = null;
                }
            }
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden) return;
            int x = 6, y = 6;
            ctx.drawTextWithShadow(mc.textRenderer, "GhostLilac", x, y, COLOR);
            ctx.drawTextWithShadow(mc.textRenderer, "Trail  " + (trail ? "ON" : "OFF"), x, y + 11, COLOR);
            ctx.drawTextWithShadow(mc.textRenderer, "Shockwave  " + (shockwave ? "ON" : "OFF"), x, y + 22, COLOR);
            ctx.drawTextWithShadow(mc.textRenderer, "Sky  " + (sky ? "ON" : "OFF"), x, y + 33, COLOR);
            ctx.drawTextWithShadow(mc.textRenderer, "Hitsplash  " + (hitsplash ? "ON" : "OFF"), x, y + 44, COLOR);
            ctx.drawTextWithShadow(mc.textRenderer, "Afterglow  " + (afterglow ? "ON" : "OFF"), x, y + 55, COLOR);
        });
    }

    private static KeyBinding key(String name, int code) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(name, code, "category.ghostlilac"));
    }

    private static boolean toggle(MinecraftClient c, String name, boolean value) {
        boolean v = !value;
        if (c.player != null) {
            c.player.sendMessage(Text.literal(name + ": " + (v ? "ON" : "OFF")), true);
        }
        return v;
    }
}
