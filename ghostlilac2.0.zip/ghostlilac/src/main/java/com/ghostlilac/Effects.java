package com.ghostlilac;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

public final class Effects {
    public static final int LILAC = 0xC9A7FF;
    private static final Random RNG = new Random();

    private static int shockAge = -1;
    private static Vec3d shockOrigin = Vec3d.ZERO;
    private static final int SHOCK_LIFE = 26;

    private Effects() {}

    private static DustParticleEffect dust(float size) {
        return new DustParticleEffect(LILAC, size);
    }

    // ---------- Hitsplash ----------
    public static void hitSplash(Vec3d pos) {
        ClientWorld w = MinecraftClient.getInstance().world;
        if (w == null) return;
        for (int i = 0; i < 28; i++) {
            double vx = (RNG.nextDouble() - 0.5) * 0.5;
            double vy = RNG.nextDouble() * 0.35;
            double vz = (RNG.nextDouble() - 0.5) * 0.5;
            w.addParticle(ParticleTypes.SPLASH, pos.x, pos.y, pos.z, vx, vy, vz);
            w.addParticle(dust(1.1f), pos.x, pos.y, pos.z, vx, vy, vz);
        }
        for (int i = 0; i < 10; i++) {
            double ox = (RNG.nextDouble() - 0.5) * 0.8;
            double oz = (RNG.nextDouble() - 0.5) * 0.8;
            w.addParticle(ParticleTypes.FALLING_WATER, pos.x + ox, pos.y - 0.3, pos.z + oz, 0, 0, 0);
            w.addParticle(dust(0.9f), pos.x + ox, pos.y - 0.6, pos.z + oz, 0, -0.05, 0);
        }
    }

    // ---------- Afterglow ----------
    public static void afterglow(Vec3d feet, double height, double width) {
        ClientWorld w = MinecraftClient.getInstance().world;
        if (w == null) return;
        for (int i = 0; i < 70; i++) {
            double x = feet.x + (RNG.nextDouble() - 0.5) * width * 1.4;
            double y = feet.y + RNG.nextDouble() * height;
            double z = feet.z + (RNG.nextDouble() - 0.5) * width * 1.4;
            double vy = 0.04 + RNG.nextDouble() * 0.08;
            w.addParticle(dust(1.4f), x, y, z, 0, vy, 0);
            if (i % 4 == 0) w.addParticle(ParticleTypes.END_ROD, x, y, z, 0, vy * 1.5, 0);
        }
    }

    // ---------- Trail ----------
    public static void trail(PlayerEntity p) {
        Vec3d v = p.getVelocity();
        double sp = Math.sqrt(v.x * v.x + v.z * v.z);
        if (sp < 0.06) return;
        ClientWorld w = MinecraftClient.getInstance().world;
        if (w == null) return;
        Vec3d back = new Vec3d(-v.x, 0, -v.z).normalize().multiply(0.3);
        for (int i = 0; i < 6; i++) {
            double x = p.getX() + back.x + (RNG.nextDouble() - 0.5) * 0.35;
            double y = p.getY() + 0.1 + RNG.nextDouble() * 1.6;
            double z = p.getZ() + back.z + (RNG.nextDouble() - 0.5) * 0.35;
            w.addParticle(dust(1.2f), x, y, z, 0, 0, 0);
            if (i % 2 == 0) w.addParticle(ParticleTypes.END_ROD, x, y, z, 0, 0, 0);
        }
    }

    // ---------- Shockwave (onda no chao + tremor) ----------
    public static void startShockwave(Vec3d origin) {
        shockOrigin = origin;
        shockAge = 0;
    }

    public static void tick() {
        if (shockAge < 0) return;
        ClientWorld w = MinecraftClient.getInstance().world;
        if (w == null) { shockAge = -1; return; }

        double radius = 0.5 + shockAge * 0.6;
        int n = (int) (radius * 16) + 14;
        for (int i = 0; i < n; i++) {
            double a = (Math.PI * 2 * i) / n;
            double x = shockOrigin.x + Math.cos(a) * radius;
            double z = shockOrigin.z + Math.sin(a) * radius;
            // anel colado no chao
            w.addParticle(dust(1.0f), x, shockOrigin.y + 0.08, z, 0, 0.0, 0);
            // luzes lilas nas bordas da onda
            if (i % 4 == 0) {
                w.addParticle(ParticleTypes.END_ROD, x, shockOrigin.y + 0.2, z, 0, 0.04, 0);
            }
            // segundo anel mais interno, mais baixo
            if (shockAge > 3) {
                double r2 = radius * 0.7;
                w.addParticle(dust(0.8f),
                        shockOrigin.x + Math.cos(a) * r2, shockOrigin.y + 0.05,
                        shockOrigin.z + Math.sin(a) * r2, 0, 0, 0);
            }
        }
        shockAge++;
        if (shockAge > SHOCK_LIFE) shockAge = -1;
    }

    public static float shakeStrength() {
        if (shockAge < 0) return 0f;
        return Math.max(0f, 1f - (shockAge / (float) SHOCK_LIFE));
    }

    public static float rand() {
        return RNG.nextFloat() - 0.5f;
    }

    // ---------- Sky ----------
    /** Recebe a cor original do ceu (0..1) e devolve o ceu lilas animado. */
    public static float[] skyRgb(float or, float og, float ob, long time, float tickDelta) {
        float t = (time + tickDelta) * 0.012f;
        float pulse = 0.5f + 0.5f * (float) Math.sin(t);
        float shift = 0.5f + 0.5f * (float) Math.sin(t * 0.37f + 1.3f);
        float r = 0.38f + 0.26f * pulse;
        float g = 0.16f + 0.16f * shift;
        float b = 0.72f + 0.22f * pulse;
        float lum = Math.max(or, Math.max(og, ob));
        float k = 0.22f + 0.78f * Math.min(1f, lum);
        return new float[]{ Math.min(1f, r * k), Math.min(1f, g * k), Math.min(1f, b * k) };
    }
}
