package com.ghostlilac;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

public final class Effects {
    public static final int LILAC = 0xC9A7FF;
    private static final Random RNG = new Random();

    // estado da shockwave
    private static int shockAge = -1;
    private static Vec3d shockOrigin = Vec3d.ZERO;
    private static final int SHOCK_LIFE = 22;

    private Effects() {}

    private static DustParticleEffect dust(float size) {
        return new DustParticleEffect(LILAC, size);
    }

    /** Respingo de agua lilas no ponto do hit, com gotas que caem no chao. */
    public static void hitSplash(Vec3d pos) {
        ClientWorld w = MinecraftClient.getInstance().world;
        if (w == null) return;
        for (int i = 0; i < 28; i++) {
            double vx = (RNG.nextDouble() - 0.5) * 0.5;
            double vy = RNG.nextDouble() * 0.35;
            double vz = (RNG.nextDouble() - 0.5) * 0.5;
            w.addParticle(ParticleTypes.SPLASH, pos.x, pos.y, pos.z, vx, vy, vz);
            w.addParticle(dust(1.1f), pos.x, pos.y, pos.z, vx, vy, vz);
        }
        for (int i = 0; i < 10; i++) {
            double ox = (RNG.nextDouble() - 0.5) * 0.8;
            double oz = (RNG.nextDouble() - 0.5) * 0.8;
            w.addParticle(ParticleTypes.FALLING_WATER, pos.x + ox, pos.y - 0.3, pos.z + oz, 0, 0, 0);
            w.addParticle(dust(0.9f), pos.x + ox, pos.y - 0.6, pos.z + oz, 0, -0.05, 0);
        }
    }

    /** Vaporiza: nuvem lilas subindo em cima do alvo morto. */
    public static void afterglow(Vec3d feet, double height, double width) {
        ClientWorld w = MinecraftClient.getInstance().world;
        if (w == null) return;
        for (int i = 0; i < 70; i++) {
            double x = feet.x + (RNG.nextDouble() - 0.5) * width * 1.4;
            double y = feet.y + RNG.nextDouble() * height;
            double z = feet.z + (RNG.nextDouble() - 0.5) * width * 1.4;
            double vy = 0.04 + RNG.nextDouble() * 0.08;
            w.addParticle(dust(1.4f), x, y, z, 0, vy, 0);
            if (i % 4 == 0) {
                w.addParticle(ParticleTypes.END_ROD, x, y, z, 0, vy * 1.5, 0);
            }
        }
    }

    public static void startShockwave(Vec3d origin) {
        shockOrigin = origin;
        shockAge = 0;
    }

    /** Chamado todo tick de cliente. */
    public static void tick() {
        if (shockAge < 0) return;
        ClientWorld w = MinecraftClient.getInstance().world;
        if (w == null) { shockAge = -1; return; }

        double radius = 0.4 + shockAge * 0.55;
        int n = (int) (radius * 14) + 12;
        for (int i = 0; i < n; i++) {
            double a = (Math.PI * 2 * i) / n;
            double x = shockOrigin.x + Math.cos(a) * radius;
            double z = shockOrigin.z + Math.sin(a) * radius;
            w.addParticle(dust(1.0f), x, shockOrigin.y + 0.1, z, 0, 0.02, 0);
            // luzes nas bordas da onda
            if (i % 5 == 0) {
                w.addParticle(ParticleTypes.END_ROD, x, shockOrigin.y + 0.15, z, 0, 0.03, 0);
            }
        }
        shockAge++;
        if (shockAge > SHOCK_LIFE) shockAge = -1;
    }

    /** 0..1, usado pelo mixin da camera. */
    public static float shakeStrength() {
        if (shockAge < 0) return 0f;
        return Math.max(0f, 1f - (shockAge / (float) SHOCK_LIFE));
    }

    public static float rand() {
        return RNG.nextFloat() - 0.5f;
    }
}
