package com.ghostlilac;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class GhostLilacClient implements ClientModInitializer {
    public static boolean hitsplash = true;
    public static boolean afterglow = true;
    public static boolean shockwave = true;

    private static final int COLOR = 0xFFC9A7FF; // lilas claro, com alpha

    private static KeyBinding kHit, kGlow, kShock, kTest;
    private static LivingEntity lastTarget;
    private static long lastTargetTick;

    @Override
    public void onInitializeClient() {
        kHit   = key("key.ghostlilac.hitsplash",  GLFW.GLFW_KEY_J);
        kGlow  = key("key.ghostlilac.afterglow",  GLFW.GLFW_KEY_K);
        kShock = key("key.ghostlilac.shockwave",  GLFW.GLFW_KEY_L);
        kTest  = key("key.ghostlilac.test_shock", GLFW.GLFW_KEY_V);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient && entity instanceof LivingEntity living) {
                Vec3d p = living.getPos().add(0, living.getHeight() * 0.6, 0);
                if (hitsplash) Effects.hitSplash(p);
                if (shockwave) Effects.startShockwave(living.getPos());
                lastTarget = living;
                lastTargetTick = world.getTime();
            }
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (kHit.wasPressed())   hitsplash = toggle(client, "Hitsplash", hitsplash);
            while (kGlow.wasPressed())  afterglow = toggle(client, "Afterglow", afterglow);
            while (kShock.wasPressed()) shockwave = toggle(client, "Shockwave", shockwave);
            while (kTest.wasPressed()) {
                if (client.player != null) Effects.startShockwave(client.player.getPos());
            }

            Effects.tick();

            if (lastTarget != null && client.world != null) {
                if (!lastTarget.isAlive()) {
                    if (afterglow) {
                        Effects.afterglow(lastTarget.getPos(), lastTarget.getHeight(), lastTarget.getWidth());
                    }
                    lastTarget = null;
                } else if (client.world.getTime() - lastTargetTick > 100) {
                    lastTarget = null;
                }
            }
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden) return;
            int x = 6, y = 6;
            ctx.drawTextWithShadow(mc.textRenderer, "GhostLilac", x, y, COLOR);
            ctx.drawTextWithShadow(mc.textRenderer, "Hitsplash  " + (hitsplash ? "ON" : "OFF"), x, y + 11, COLOR);
            ctx.drawTextWithShadow(mc.textRenderer, "Afterglow  " + (afterglow ? "ON" : "OFF"), x, y + 22, COLOR);
            ctx.drawTextWithShadow(mc.textRenderer, "Shockwave  " + (shockwave ? "ON" : "OFF"), x, y + 33, COLOR);
        });
    }

    private static KeyBinding key(String name, int code) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(name, code, "category.ghostlilac"));
    }

    private static boolean toggle(MinecraftClient c, String name, boolean value) {
        boolean v = !value;
        if (c.player != null) {
            c.player.sendMessage(Text.literal(name + ": " + (v ? "ON" : "OFF")), true);
        }
        return v;
    }
}
