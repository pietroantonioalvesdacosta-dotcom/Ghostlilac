# GhostLilac (fase 1) - Fabric 1.21.4

Teclas: J hitsplash, K afterglow, L shockwave, V testar shockwave.

Como buildar:
1. Instale o JDK 21.
2. Dentro da pasta: `gradle wrapper --gradle-version 8.12` (ou copie os arquivos para o template oficial do Fabric).
3. `./gradlew build` -> o .jar fica em build/libs/ (use o que NAO termina em -sources).
4. Coloque o .jar + Fabric API na pasta mods.
